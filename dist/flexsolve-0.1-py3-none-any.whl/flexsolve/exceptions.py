# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 23:40:01 2019

@author: yoelr
"""

__all__ = ('SolverError',)

class SolverError(RuntimeError):
    """RuntimeError regarding solvers."""